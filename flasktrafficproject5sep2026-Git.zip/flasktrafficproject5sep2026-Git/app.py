from flask import Flask, render_template, Response, request
import serial
import time
ser = serial.Serial('___________', 9600)  #Object of Serial Port
ser.timeout = 1
app = Flask(__name__)
#User-Defined Fn
def turnOn(device):
    print('Turn on - ', device)
    ser.write(bytes(_______________, 'UTF-8')) #Write on serial port in bytes 010101 form
def off():
    ser.write(str('off').encode())  #OR ser.write(bytes('off', 'UTF-8'))
def disconnect():
    ser.close()  #To close Serial port without it you get Access Denied on Next Run
@app.route("/", methods=['GET', 'POST'])  # / represent home page (first page)
def home():  #no tab
    dict=request.form.to_dict()  #1tab -Take request form data of client
    if request.method=='POST':
        if 'red' in dict:  turnOn('R')       #2 tab
        elif '_______' in dict: turnOn('G')
        elif '____________' in dict: turnOn('Y')
        elif 'light' in dict: turnOn('T')
        elif 'off' in dict: turnOn('L')
        elif 'dis' in dict: disconnect()
    return render_template('index.html') #1tab - Means show page to the client
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=_______________)
