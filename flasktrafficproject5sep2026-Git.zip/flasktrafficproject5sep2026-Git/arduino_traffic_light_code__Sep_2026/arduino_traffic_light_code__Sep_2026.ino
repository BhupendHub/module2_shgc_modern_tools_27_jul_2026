const int redPin = 13;   
const int yellowPin = 12;  
const int greenPin = 8;
int incomingByte;      // a variable to read incoming serial data into

void setup() {
  Serial.begin(9600);     // initialize serial communication
  // initialize the LED pin as an output:
  pinMode(redPin, OUTPUT);  pinMode(yellowPin, OUTPUT);
  pinMode(greenPin, OUTPUT);
}
void loop() {
  // see if there's incoming serial data:
  if (Serial.available() > 0) {
    // read the oldest byte in the serial buffer:
    incomingByte = Serial.read();  //To read available data as integer
    //Turn Off All LED's
    digitalWrite(redPin, LOW);    digitalWrite(yellowPin, LOW);
    digitalWrite(greenPin, LOW);   // digitalWrite(lightPin, LOW);
    if (incomingByte == 'R') {      digitalWrite(redPin, HIGH);    }
    else if (incomingByte == 'Y') {  digitalWrite(yellowPin, HIGH);    }
    else if (incomingByte == 'G') {   digitalWrite(greenPin, HIGH); }
  } //if
}  //fn